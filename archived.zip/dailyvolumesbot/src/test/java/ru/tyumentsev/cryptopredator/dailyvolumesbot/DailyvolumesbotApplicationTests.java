package ru.tyumentsev.cryptopredator.dailyvolumesbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DailyvolumesbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
