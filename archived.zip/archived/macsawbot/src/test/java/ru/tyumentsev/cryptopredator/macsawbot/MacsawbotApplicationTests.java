package ru.tyumentsev.cryptopredator.macsawbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MacsawbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
