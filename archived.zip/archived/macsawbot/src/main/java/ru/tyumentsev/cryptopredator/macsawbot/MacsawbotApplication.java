package ru.tyumentsev.cryptopredator.macsawbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MacsawbotApplication {

	public static void main(String[] args) {
		SpringApplication.run(MacsawbotApplication.class, args);
	}

}
