package ru.tyumentsev.cryptopredator.volumenimblebot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VolumenimblebotApplication {

	public static void main(String[] args) {
		SpringApplication.run(VolumenimblebotApplication.class, args);
	}

}
