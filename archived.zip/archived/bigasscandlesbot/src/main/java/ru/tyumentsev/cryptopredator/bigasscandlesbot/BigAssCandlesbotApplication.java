package ru.tyumentsev.cryptopredator.bigasscandlesbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BigAssCandlesbotApplication {

	public static void main(String[] args) {
		SpringApplication.run(BigAssCandlesbotApplication.class, args);
	}

}
