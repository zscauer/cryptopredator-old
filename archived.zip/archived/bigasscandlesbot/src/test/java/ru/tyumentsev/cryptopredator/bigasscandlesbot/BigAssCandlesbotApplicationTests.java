package ru.tyumentsev.cryptopredator.bigasscandlesbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BigAssCandlesbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
